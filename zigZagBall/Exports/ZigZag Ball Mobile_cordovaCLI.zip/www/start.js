"use strict";

(function() {

	document.addEventListener("deviceready", function ()
	{
		window.cr_createRuntime({
			exportType: "cordova"
		});

	}, false);
	
})();